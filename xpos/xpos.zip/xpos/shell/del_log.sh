#!/bin/bash
find $HOME/log -mtime +300 -name "*" -exec rm -rf {} \;

